package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PowerOff
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Esp32Config
import com.example.data.model.Esp32Status
import com.example.data.model.LightGroup
import com.example.ui.components.HudTelemetryBar
import com.example.ui.components.JarvisArcIndicator
import com.example.ui.components.LightGroupCard
import com.example.ui.theme.ArcReactorCyan
import com.example.ui.theme.JarvisBorderSubtle
import com.example.ui.theme.JarvisCarbon
import com.example.ui.theme.JarvisMatteBlack
import com.example.ui.theme.JarvisRedBright
import com.example.ui.theme.JarvisRedDark
import com.example.ui.theme.JarvisRedNeon
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HomeScreen(
    groups: List<LightGroup>,
    config: Esp32Config,
    status: Esp32Status,
    selectedFilter: String,
    onFilterSelect: (String) -> Unit,
    onToggleGroup: (Int, Boolean) -> Unit,
    onToggleIndividualLight: (Int, Int, Boolean) -> Unit,
    onBrightnessChange: (Int, Float) -> Unit,
    onTurnAllLights: (Boolean) -> Unit,
    onOpenVoiceDialog: () -> Unit,
    onRefreshPing: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val totalActiveBulbs = groups.sumOf { it.activeCount }
    val totalWatts = groups.sumOf { it.totalWatts.toDouble() }.toFloat()
    val isAnyLightOn = totalActiveBulbs > 0

    val filteredGroups = remember(groups, selectedFilter) {
        when (selectedFilter) {
            "ZONE_A" -> groups.filter { it.zone == "Zone Alpha" }
            "ZONE_B" -> groups.filter { it.zone == "Zone Beta" }
            "ACTIVE" -> groups.filter { it.isAnyOn }
            else -> groups
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisMatteBlack),
        containerColor = JarvisMatteBlack,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBars)
            ) {
                HudTelemetryBar(
                    status = status,
                    config = config,
                    onRefreshPing = onRefreshPing,
                    onOpenSettings = onOpenSettings
                )
            }
        },
        floatingActionButton = {
            // Futuristic Iron Man Voice Microphone Action Button
            Box(
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(bottom = 8.dp)
            ) {
                FloatingActionButton(
                    onClick = onOpenVoiceDialog,
                    containerColor = JarvisRedNeon,
                    contentColor = JarvisMatteBlack,
                    shape = CircleShape,
                    modifier = Modifier
                        .size(62.dp)
                        .border(2.dp, JarvisRedBright, CircleShape)
                        .testTag("floating_voice_mic_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Voice Directive",
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("home_screen_content"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Hero: Glowing Circular JARVIS Arc Reactor Assistant Indicator
            item(key = "jarvis_arc_hero") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(CutCornerShape(14.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(JarvisCarbon, JarvisSurface, JarvisMatteBlack)
                            )
                        )
                        .border(1.dp, JarvisBorderSubtle, CutCornerShape(14.dp))
                        .padding(vertical = 16.dp, horizontal = 14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "STARK AUTOMATION CORE",
                        fontFamily = OrbitronFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = ArcReactorCyan,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "12 Wall Array • iQOO Z10 Controller",
                        fontFamily = RajdhaniFontFamily,
                        fontSize = 12.sp,
                        color = TextMuted
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    JarvisArcIndicator(
                        size = 150.dp,
                        isActive = isAnyLightOn,
                        activeLightsCount = totalActiveBulbs,
                        totalLightsCount = 36,
                        onClick = onOpenVoiceDialog
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Live System Metrics Readout
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(JarvisMatteBlack)
                            .border(1.dp, JarvisBorderSubtle, RoundedCornerShape(8.dp))
                            .padding(vertical = 8.dp, horizontal = 12.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "ACTIVE BULBS",
                                fontFamily = OrbitronFontFamily,
                                fontSize = 9.sp,
                                color = TextMuted
                            )
                            Text(
                                text = "$totalActiveBulbs / 36",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = if (isAnyLightOn) JarvisRedBright else TextSecondary
                            )
                        }

                        Box(
                            modifier = Modifier
                                .width(1.dp)
                                .height(26.dp)
                                .background(JarvisBorderSubtle)
                        )

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "POWER DRAW",
                                fontFamily = OrbitronFontFamily,
                                fontSize = 9.sp,
                                color = TextMuted
                            )
                            Text(
                                text = "${String.format("%.1f", totalWatts)} W",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = ArcReactorCyan
                            )
                        }

                        Box(
                            modifier = Modifier
                                .width(1.dp)
                                .height(26.dp)
                                .background(JarvisBorderSubtle)
                        )

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "ESP32 LINK",
                                fontFamily = OrbitronFontFamily,
                                fontSize = 9.sp,
                                color = TextMuted
                            )
                            Text(
                                text = if (config.isDemoMode) "DEMO" else "${status.pingMs}ms",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = if (config.isDemoMode) ArcReactorCyan else JarvisRedBright
                            )
                        }
                    }
                }
            }

            // Master Controls: All Lights ON & All Lights OFF
            item(key = "master_controls") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // ALL LIGHTS ON BUTTON
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(CutCornerShape(8.dp))
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(JarvisRedNeon, JarvisRedBright)
                                )
                            )
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                                onClick = { onTurnAllLights(true) }
                            )
                            .padding(vertical = 12.dp)
                            .testTag("all_lights_on_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = "Turn All Lights On",
                                tint = JarvisMatteBlack,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ALL LIGHTS ON",
                                fontFamily = OrbitronFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = JarvisMatteBlack
                            )
                        }
                    }

                    // ALL LIGHTS OFF BUTTON
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(CutCornerShape(8.dp))
                            .background(JarvisCarbon)
                            .border(1.dp, JarvisRedDark, CutCornerShape(8.dp))
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null,
                                onClick = { onTurnAllLights(false) }
                            )
                            .padding(vertical = 12.dp)
                            .testTag("all_lights_off_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.PowerOff,
                                contentDescription = "Turn All Lights Off",
                                tint = JarvisRedBright,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ALL LIGHTS OFF",
                                fontFamily = OrbitronFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }

            // Zone / Filter Selector Tabs
            item(key = "zone_filters") {
                val filters = listOf(
                    "ALL" to "ALL WALLS (12)",
                    "ZONE_A" to "ZONE ALPHA (1-6)",
                    "ZONE_B" to "ZONE BETA (7-12)",
                    "ACTIVE" to "ACTIVE ONLY ($totalActiveBulbs)"
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(filters) { (key, label) ->
                        val isSelected = selectedFilter == key
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (isSelected) JarvisRedNeon else JarvisCarbon)
                                .border(
                                    1.dp,
                                    if (isSelected) JarvisRedBright else JarvisBorderSubtle,
                                    RoundedCornerShape(16.dp)
                                )
                                .clickable { onFilterSelect(key) }
                                .padding(horizontal = 12.dp, vertical = 7.dp)
                                .testTag("filter_tab_$key")
                        ) {
                            Text(
                                text = label,
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (isSelected) JarvisMatteBlack else TextSecondary
                            )
                        }
                    }
                }
            }

            // Section Header
            item(key = "wall_header") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "WALL GROUPS (3 LIGHTS PER WALL)",
                        fontFamily = OrbitronFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = TextSecondary,
                        letterSpacing = 1.sp
                    )

                    Text(
                        text = "${filteredGroups.size} OF 12 SHOWN",
                        fontFamily = RajdhaniFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        color = ArcReactorCyan
                    )
                }
            }

            // 12 Wall Groups List
            items(
                items = filteredGroups,
                key = { it.id }
            ) { group ->
                LightGroupCard(
                    group = group,
                    onToggleGroup = { turnOn -> onToggleGroup(group.id, turnOn) },
                    onToggleIndividualLight = { lightIndex, turnOn ->
                        onToggleIndividualLight(group.id, lightIndex, turnOn)
                    },
                    onBrightnessChange = { newBrightness ->
                        onBrightnessChange(group.id, newBrightness)
                    }
                )
            }

            // Empty state if active filter returns no lights
            if (filteredGroups.isEmpty()) {
                item(key = "empty_active_state") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(JarvisCarbon)
                            .border(1.dp, JarvisBorderSubtle, RoundedCornerShape(8.dp))
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "NO WALL GROUPS ACTIVE",
                                fontFamily = OrbitronFontFamily,
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                            Text(
                                text = "Tap 'ALL LIGHTS ON' or select individual walls above.",
                                fontFamily = RajdhaniFontFamily,
                                fontSize = 12.sp,
                                color = TextMuted
                            )
                        }
                    }
                }
            }

            // Bottom Spacing for Floating Action Button and Insets
            item(key = "bottom_spacer") {
                Spacer(modifier = Modifier.height(72.dp))
            }
        }
    }
}
