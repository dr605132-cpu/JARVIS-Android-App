package com.example.data.repository

import com.example.data.model.ConnectionState
import com.example.data.model.Esp32Config
import com.example.data.model.Esp32Status
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

class Esp32Repository {
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(2500, TimeUnit.MILLISECONDS)
        .readTimeout(2500, TimeUnit.MILLISECONDS)
        .writeTimeout(2500, TimeUnit.MILLISECONDS)
        .build()

    suspend fun ping(config: Esp32Config): Esp32Status = withContext(Dispatchers.IO) {
        if (config.isDemoMode) {
            delay(40) // realistic local latency
            return@withContext Esp32Status(
                state = ConnectionState.DEMO_MODE,
                pingMs = (15..32).random().toLong(),
                signalDbm = (-60..-48).random(),
                lastSyncTime = System.currentTimeMillis(),
                message = "Demo Simulation Active (ESP32 Ready: ${config.baseUrl})"
            )
        }

        val startTime = System.currentTimeMillis()
        try {
            val request = Request.Builder()
                .url("${config.baseUrl}/status")
                .header("User-Agent", "JARVIS-Home-Android/1.0")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                val elapsed = System.currentTimeMillis() - startTime
                if (response.isSuccessful) {
                    Esp32Status(
                        state = ConnectionState.CONNECTED,
                        pingMs = elapsed,
                        signalDbm = -52,
                        lastSyncTime = System.currentTimeMillis(),
                        message = "Connected to ESP32 at ${config.ipAddress}:${config.port}"
                    )
                } else {
                    Esp32Status(
                        state = ConnectionState.ERROR,
                        pingMs = elapsed,
                        lastSyncTime = System.currentTimeMillis(),
                        message = "ESP32 returned HTTP error: ${response.code}"
                    )
                }
            }
        } catch (e: Exception) {
            val elapsed = System.currentTimeMillis() - startTime
            Esp32Status(
                state = ConnectionState.OFFLINE,
                pingMs = elapsed,
                lastSyncTime = System.currentTimeMillis(),
                message = "Unreachable at ${config.ipAddress} (${e.localizedMessage ?: "Timeout"})"
            )
        }
    }

    suspend fun updateGroupState(
        config: Esp32Config,
        groupId: Int,
        lights: List<Boolean>,
        brightness: Float
    ): Result<String> = withContext(Dispatchers.IO) {
        if (config.isDemoMode) {
            delay(35)
            val anyOn = lights.any { it }
            return@withContext Result.success("Group $groupId state updated (Demo): ${if (anyOn) "ON" else "OFF"}")
        }

        try {
            // Support both standard GET query and REST JSON payload
            val lightsParam = lights.joinToString(",") { if (it) "1" else "0" }
            val url = "${config.baseUrl}/api/group?id=$groupId&lights=$lightsParam&brightness=${brightness.toInt()}"

            val request = Request.Builder()
                .url(url)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success("ESP32 Ack: Wall $groupId updated")
                } else {
                    Result.failure(IOException("ESP32 HTTP ${response.code}"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateAllGroups(
        config: Esp32Config,
        allOn: Boolean
    ): Result<String> = withContext(Dispatchers.IO) {
        if (config.isDemoMode) {
            delay(60)
            return@withContext Result.success("All 12 wall groups switched ${if (allOn) "ON" else "OFF"} (Demo)")
        }

        try {
            val url = "${config.baseUrl}/api/all?state=${if (allOn) "1" else "0"}"
            val request = Request.Builder()
                .url(url)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success("ESP32 Ack: All lights set to ${if (allOn) "ON" else "OFF"}")
                } else {
                    Result.failure(IOException("ESP32 HTTP ${response.code}"))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
