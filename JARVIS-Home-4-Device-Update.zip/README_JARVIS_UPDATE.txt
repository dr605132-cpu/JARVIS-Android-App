JARVIS HOME - 4 DEVICE DASHBOARD UPDATE

Dashboard channels:
1. Room Lights - relay channel 1
2. Projector + TV + Speakers - relay channel 2
3. AC - phone IR control UI; requires the exact AC brand/model and matching IR protocol data before commands can be transmitted
4. Ambient Lights - relay channel 4

ESP32 API CONTRACT USED BY THIS APP
When Demo Mode is OFF, the Android app sends:
GET /status
GET /api/relay?channel=1&state=1
GET /api/relay?channel=1&state=0
...same for channels 2 and 4.

Your ESP32 firmware must implement this endpoint and map relay channels to the intended loads. This ZIP does NOT contain ESP32 firmware. Do not connect mains loads until an electrician has checked relay contact ratings, isolation, fusing, enclosure and wiring. AC compressor power should not be switched rapidly; use the AC manufacturer's IR control for normal operation.

AC IR
The app checks whether Android reports a Consumer IR emitter and shows the AC control setup panel. It intentionally does not send guessed IR codes. Full AC controls (power, temperature, mode, fan, swing, timer) require the AC brand and exact model or remote model, then a compatible IR command profile.

BUILD
A GitHub Actions workflow is included at .github/workflows/build.yml. Push the project to GitHub and run the workflow (or push to main/master). Download the artifact named JARVIS-Home-debug-apk.

IMPORTANT
This source update has not been built or tested on the user's phone or actual ESP32 hardware in this environment. Demo Mode remains enabled by default. Relay control will not work until matching ESP32 firmware is installed and configured with the app's IP/port.
