package com.example.data.model

data class LightGroup(
    val id: Int,
    val wallName: String,
    val zone: String,
    val lights: List<Boolean> = listOf(false, false, false),
    val brightness: Float = 100f,
    val wattsPerLight: Float = 8.5f
) {
    val isAnyOn: Boolean get() = lights.any { it }
    val isAllOn: Boolean get() = lights.all { it }
    val activeCount: Int get() = lights.count { it }
    val totalWatts: Float get() = if (isAnyOn) activeCount * wattsPerLight * (brightness / 100f) else 0f
}
