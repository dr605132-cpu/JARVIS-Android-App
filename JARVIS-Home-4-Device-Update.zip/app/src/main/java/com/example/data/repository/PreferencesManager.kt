package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.Esp32Config

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("jarvis_smart_home_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_IP_ADDRESS = "key_ip_address"
        private const val KEY_PORT = "key_port"
        private const val KEY_DEMO_MODE = "key_demo_mode"
        private const val KEY_HAPTIC = "key_haptic"
        private const val KEY_SOUND = "key_sound"
        private const val KEY_WALL_PREFIX = "key_wall_name_"
    }

    fun loadConfig(): Esp32Config {
        return Esp32Config(
            ipAddress = prefs.getString(KEY_IP_ADDRESS, "192.168.1.100") ?: "192.168.1.100",
            port = prefs.getInt(KEY_PORT, 80),
            isDemoMode = prefs.getBoolean(KEY_DEMO_MODE, true),
            hapticEnabled = prefs.getBoolean(KEY_HAPTIC, true),
            soundEffectsEnabled = prefs.getBoolean(KEY_SOUND, true)
        )
    }

    fun saveConfig(config: Esp32Config) {
        prefs.edit()
            .putString(KEY_IP_ADDRESS, config.ipAddress)
            .putInt(KEY_PORT, config.port)
            .putBoolean(KEY_DEMO_MODE, config.isDemoMode)
            .putBoolean(KEY_HAPTIC, config.hapticEnabled)
            .putBoolean(KEY_SOUND, config.soundEffectsEnabled)
            .apply()
    }

    fun saveWallName(groupId: Int, name: String) {
        prefs.edit().putString(KEY_WALL_PREFIX + groupId, name).apply()
    }

    fun getWallName(groupId: Int, defaultName: String): String {
        return prefs.getString(KEY_WALL_PREFIX + groupId, defaultName) ?: defaultName
    }
}
