package com.example.data.model

data class Esp32Config(
    val ipAddress: String = "192.168.1.100",
    val port: Int = 80,
    val isDemoMode: Boolean = true,
    val timeoutMs: Long = 2000L,
    val hapticEnabled: Boolean = true,
    val soundEffectsEnabled: Boolean = true,
    val autoSyncIntervalSec: Int = 5
) {
    val baseUrl: String
        get() = if (port == 80) "http://$ipAddress" else "http://$ipAddress:$port"
}

enum class ConnectionState {
    DEMO_MODE,
    CONNECTING,
    CONNECTED,
    OFFLINE,
    ERROR
}

data class Esp32Status(
    val state: ConnectionState = ConnectionState.DEMO_MODE,
    val pingMs: Long = 18L,
    val signalDbm: Int = -54,
    val lastSyncTime: Long = System.currentTimeMillis(),
    val message: String = "Demo Simulation Active (Ready for ESP32 hardware)"
)
