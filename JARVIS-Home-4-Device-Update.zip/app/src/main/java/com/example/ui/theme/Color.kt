package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Stark Industries / Iron Man JARVIS Color Palette
// Matte Black & Deep Slate Backgrounds
val JarvisMatteBlack = Color(0xFF090A0D)
val JarvisCarbon = Color(0xFF101217)
val JarvisSurface = Color(0xFF141720)
val JarvisSurfaceElevated = Color(0xFF1A1E29)
val JarvisBorderSubtle = Color(0xFF282D3D)

// Neon Red & Crimson Accents
val JarvisRedNeon = Color(0xFFFF2438)
val JarvisRedBright = Color(0xFFFF4D5E)
val JarvisRedGlow = Color(0xFFFF172E)
val JarvisRedDark = Color(0xFF5E0B14)
val JarvisRedBorder = Color(0x66FF2438)

// Subsidiary HUD & Telemetry Colors
val ArcReactorCyan = Color(0xFF00E5FF)
val ArcReactorCyanDim = Color(0xFF007A8A)
val StarkAmber = Color(0xFFFFB300)
val StarkGold = Color(0xFFFFD54F)

// Status Colors
val StatusSuccess = Color(0xFF00E676)
val StatusWarning = Color(0xFFFF9100)
val StatusError = Color(0xFFFF1744)

// Text Hierarchy
val TextPrimary = Color(0xFFF3F5FA)
val TextSecondary = Color(0xFF9EA3B5)
val TextMuted = Color(0xFF5F657A)
val TextRedAccent = Color(0xFFFF6B7A)
