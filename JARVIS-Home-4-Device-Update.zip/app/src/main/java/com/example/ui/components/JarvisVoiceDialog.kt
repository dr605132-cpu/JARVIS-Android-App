package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ArcReactorCyan
import com.example.ui.theme.JarvisBorderSubtle
import com.example.ui.theme.JarvisCarbon
import com.example.ui.theme.JarvisMatteBlack
import com.example.ui.theme.JarvisRedBright
import com.example.ui.theme.JarvisRedDark
import com.example.ui.theme.JarvisRedNeon
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisVoiceDialog(
    isListening: Boolean,
    lastVoiceCommand: String,
    jarvisResponse: String,
    onSendCommand: (String) -> Unit,
    onStartListening: () -> Unit,
    onDismiss: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "voice_wave")

    // Pulsing animated wave bar heights for futuristic speech visualizer
    val bar1 by infiniteTransition.animateFloat(
        initialValue = 12f, targetValue = 48f,
        animationSpec = infiniteRepeatable(tween(400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b1"
    )
    val bar2 by infiniteTransition.animateFloat(
        initialValue = 28f, targetValue = 64f,
        animationSpec = infiniteRepeatable(tween(350, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b2"
    )
    val bar3 by infiniteTransition.animateFloat(
        initialValue = 16f, targetValue = 54f,
        animationSpec = infiniteRepeatable(tween(480, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b3"
    )
    val bar4 by infiniteTransition.animateFloat(
        initialValue = 32f, targetValue = 70f,
        animationSpec = infiniteRepeatable(tween(320, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b4"
    )
    val bar5 by infiniteTransition.animateFloat(
        initialValue = 10f, targetValue = 42f,
        animationSpec = infiniteRepeatable(tween(440, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "b5"
    )

    val sampleCommands = listOf(
        "Turn on all lights",
        "Turn off all lights",
        "Stealth protocol (dim 20%)",
        "Engage Wall 1",
        "Cut Wall 1",
        "System diagnostics"
    )

    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("jarvis_voice_dialog")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(16.dp))
                .background(
                    Brush.verticalGradient(
                        colors = listOf(JarvisCarbon, JarvisMatteBlack, JarvisRedDark.copy(alpha = 0.3f))
                    )
                )
                .border(1.5.dp, JarvisRedNeon, CutCornerShape(16.dp))
                .padding(20.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Header with close button
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(JarvisRedBright)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "JARVIS VOICE PROTOCOL",
                            fontFamily = OrbitronFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = JarvisRedBright,
                            letterSpacing = 1.sp
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Voice Assistant",
                            tint = TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Animated Speech Frequency Waveform
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(80.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(JarvisMatteBlack)
                        .border(1.dp, JarvisBorderSubtle, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(bar1, bar3, bar2, bar4, bar2, bar5, bar3, bar1).forEach { heightVal ->
                            Box(
                                modifier = Modifier
                                    .width(6.dp)
                                    .height(if (isListening) heightVal.dp else 12.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(if (isListening) JarvisRedBright else ArcReactorCyan.copy(alpha = 0.5f))
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Microphone Status / Interactive trigger
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(JarvisRedNeon, JarvisRedDark)
                            )
                        )
                        .border(2.dp, JarvisRedBright, CircleShape)
                        .clickable(onClick = onStartListening)
                        .testTag("voice_dialog_mic_trigger"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Start Voice Command",
                        tint = Color.White,
                        modifier = Modifier.size(34.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (isListening) "LISTENING FOR DIRECTIVE..." else "TAP MIC TO SPEAK",
                    fontFamily = OrbitronFontFamily,
                    fontSize = 11.sp,
                    color = if (isListening) ArcReactorCyan else TextSecondary
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Recognized Command readout
                if (lastVoiceCommand.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(JarvisCarbon)
                            .border(1.dp, JarvisBorderSubtle, RoundedCornerShape(6.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Text(
                                text = "DIRECTIVE DETECTED:",
                                fontFamily = OrbitronFontFamily,
                                fontSize = 9.sp,
                                color = TextMuted
                            )
                            Text(
                                text = "\"$lastVoiceCommand\"",
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = TextPrimary
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // JARVIS AI Response Bubble
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(JarvisCarbon)
                        .border(1.dp, ArcReactorCyan.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = ArcReactorCyan,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "JARVIS VOCAL RESPONSE:",
                                fontFamily = OrbitronFontFamily,
                                fontSize = 9.sp,
                                color = ArcReactorCyan
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = jarvisResponse,
                            fontFamily = RajdhaniFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp,
                            color = TextPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Quick Command Presets / Suggestions
                Text(
                    text = "COMMAND PRESETS (TAP TO EXECUTE):",
                    fontFamily = OrbitronFontFamily,
                    fontSize = 9.sp,
                    color = TextMuted,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(sampleCommands) { cmd ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .background(JarvisMatteBlack)
                                .border(1.dp, JarvisBorderSubtle, RoundedCornerShape(14.dp))
                                .clickable { onSendCommand(cmd) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = cmd,
                                fontFamily = RajdhaniFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }
            }
        }
    }
}
