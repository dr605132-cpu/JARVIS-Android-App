package com.example.ui.screens

import android.content.Context
import android.hardware.ConsumerIrManager
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WbTwilight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Esp32Config
import com.example.data.model.Esp32Status
import com.example.data.model.LightGroup
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    groups: List<LightGroup>, config: Esp32Config, status: Esp32Status,
    selectedFilter: String, onFilterSelect: (String) -> Unit,
    onToggleGroup: (Int, Boolean) -> Unit,
    onToggleIndividualLight: (Int, Int, Boolean) -> Unit,
    onBrightnessChange: (Int, Float) -> Unit,
    onTurnAllLights: (Boolean) -> Unit,
    onOpenVoiceDialog: () -> Unit, onRefreshPing: () -> Unit,
    onOpenSettings: () -> Unit, modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showAcInfo by remember { mutableStateOf(false) }
    val channelNames = listOf(
        Triple(1, "ROOM LIGHTS", "All room lights together"),
        Triple(2, "PROJECTOR + TV + SPEAKERS", "Home theatre master power"),
        Triple(3, "AC CONTROL", "Infrared remote control"),
        Triple(4, "AMBIENT LIGHTS", "Decorative / RGB lighting")
    )
    val irManager = remember {
        context.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
    }
    val irAvailable = irManager?.hasIrEmitter() == true
    val dark = Color(0xFF080D14)
    val panel = Color(0xFF111C29)
    val cyan = Color(0xFF35D9F2)
    val activeGroups = groups.associateBy { it.id }

    Scaffold(containerColor = dark, modifier = modifier.fillMaxSize()) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("J.A.R.V.I.S", color = cyan, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("HOME CONTROL SYSTEM", color = Color.LightGray, fontSize = 11.sp, letterSpacing = 2.sp)
                }
                IconButton(onClick = onOpenSettings, modifier = Modifier.testTag("open_settings")) {
                    Icon(Icons.Default.Settings, contentDescription = "Settings", tint = cyan)
                }
            }
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(panel).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (config.isDemoMode) "DEMO MODE" else status.state.name, color = cyan, fontWeight = FontWeight.Bold)
                    Text(if (config.isDemoMode) "Controls are simulated" else status.message, color = Color.LightGray, fontSize = 11.sp)
                }
                TextButton(onClick = onRefreshPing) { Text("CHECK LINK", color = cyan) }
            }
            Text("DEVICE CONTROL", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
            channelNames.forEach { (id, title, subtitle) ->
                val group = activeGroups[id]
                val isOn = group?.isAnyOn == true
                val icon = when (id) {
                    1 -> Icons.Default.Lightbulb
                    2 -> Icons.Default.Movie
                    3 -> Icons.Default.AcUnit
                    else -> Icons.Default.WbTwilight
                }
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(panel)
                        .border(1.dp, if (isOn) cyan.copy(alpha = .7f) else Color(0xFF26384A), RoundedCornerShape(16.dp))
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(icon, contentDescription = null, tint = if (isOn) cyan else Color.LightGray, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(subtitle, color = Color.LightGray, fontSize = 11.sp)
                        if (id == 3) Text(if (irAvailable) "PHONE IR BLASTER DETECTED" else "PHONE IR BLASTER NOT DETECTED", color = if (irAvailable) cyan else Color(0xFFFFB45C), fontSize = 9.sp)
                        else Text(if (isOn) "ON" else "OFF", color = if (isOn) cyan else Color.LightGray, fontSize = 10.sp)
                    }
                    if (id == 3) {
                        Button(onClick = { showAcInfo = true }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF17475A))) { Text("OPEN", color = Color.White) }
                    } else {
                        Switch(checked = isOn, onCheckedChange = { onToggleGroup(id, it) })
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { onToggleGroup(1, true) }, modifier = Modifier.weight(1f)) { Text("ROOM ON") }
                OutlinedButton(onClick = { onToggleGroup(1, false) }, modifier = Modifier.weight(1f)) { Text("ROOM OFF") }
            }
            Button(onClick = onOpenVoiceDialog, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF123B50))) {
                Icon(Icons.Default.Mic, contentDescription = null, tint = cyan)
                Spacer(Modifier.width(8.dp)); Text("TALK TO JARVIS", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Text("VOICE COMMANDS", color = cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text("“Room lights on”  •  “Home theatre off”  •  “Ambient lights on”  •  “AC control”", color = Color.LightGray, fontSize = 12.sp)
            Text("Relay controls require matching ESP32 firmware and wiring. AC IR commands require the exact AC brand/model and supported remote codes.", color = Color(0xFF9AA9B8), fontSize = 10.sp)
        }
    }
    if (showAcInfo) {
        AlertDialog(
            onDismissRequest = { showAcInfo = false },
            containerColor = panel,
            title = { Text("AC INFRARED CONTROL", color = cyan) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (irAvailable) "Your phone reports an IR emitter. JARVIS can use it once the AC remote profile is configured." else "This phone does not report an IR emitter to Android. AC control from the phone may not be available.", color = Color.White)
                    Text("Power, temperature, mode, fan speed, swing and timer depend on the AC model and its IR protocol. No command is sent until the correct profile is added.", color = Color.LightGray, fontSize = 12.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showAcInfo = false }) { Text("OK", color = cyan) } }
        )
    }
}
