package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LightGroup
import com.example.ui.theme.ArcReactorCyan
import com.example.ui.theme.JarvisBorderSubtle
import com.example.ui.theme.JarvisCarbon
import com.example.ui.theme.JarvisMatteBlack
import com.example.ui.theme.JarvisRedBright
import com.example.ui.theme.JarvisRedDark
import com.example.ui.theme.JarvisRedGlow
import com.example.ui.theme.JarvisRedNeon
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun LightGroupCard(
    group: LightGroup,
    onToggleGroup: (Boolean) -> Unit,
    onToggleIndividualLight: (Int, Boolean) -> Unit,
    onBrightnessChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val isAnyOn = group.isAnyOn
    val isAllOn = group.isAllOn

    val cardBorderColor by animateColorAsState(
        targetValue = if (isAnyOn) JarvisRedNeon.copy(alpha = 0.85f) else JarvisBorderSubtle,
        label = "card_border"
    )

    val cardBackground = if (isAnyOn) {
        Brush.verticalGradient(
            colors = listOf(
                JarvisCarbon,
                JarvisSurface,
                JarvisRedDark.copy(alpha = 0.15f)
            )
        )
    } else {
        Brush.verticalGradient(
            colors = listOf(
                JarvisCarbon,
                JarvisMatteBlack
            )
        )
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp))
            .background(cardBackground)
            .border(
                width = if (isAnyOn) 1.5.dp else 1.dp,
                color = cardBorderColor,
                shape = CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp)
            )
            .padding(14.dp)
            .testTag("light_group_card_${group.id}")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header: Wall Tag, Name, Power Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Futuristic Wall ID Badge
                    Box(
                        modifier = Modifier
                            .clip(CutCornerShape(topStart = 4.dp, bottomEnd = 4.dp))
                            .background(if (isAnyOn) JarvisRedNeon else JarvisBorderSubtle)
                            .padding(horizontal = 7.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = String.format("WALL %02d", group.id),
                            fontFamily = OrbitronFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            color = if (isAnyOn) JarvisMatteBlack else TextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column {
                        Text(
                            text = group.wallName,
                            fontFamily = RajdhaniFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = if (isAnyOn) TextPrimary else TextSecondary,
                            maxLines = 1
                        )
                        Text(
                            text = "${group.zone} • ${group.activeCount}/3 ON (${String.format("%.1f", group.totalWatts)}W)",
                            fontFamily = RajdhaniFontFamily,
                            fontSize = 11.sp,
                            color = if (isAnyOn) ArcReactorCyan else TextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Group Master ON / OFF Switch (Futuristic Button)
                Box(
                    modifier = Modifier
                        .clip(CutCornerShape(topStart = 6.dp, bottomEnd = 6.dp))
                        .background(
                            if (isAnyOn) JarvisRedNeon else JarvisMatteBlack
                        )
                        .border(
                            1.dp,
                            if (isAnyOn) JarvisRedBright else JarvisBorderSubtle,
                            CutCornerShape(topStart = 6.dp, bottomEnd = 6.dp)
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = { onToggleGroup(!isAnyOn) }
                        )
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("group_toggle_button_${group.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = if (isAnyOn) "Turn Off Wall" else "Turn On Wall",
                            tint = if (isAnyOn) JarvisMatteBlack else TextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isAnyOn) "CUT" else "ENGAGE",
                            fontFamily = OrbitronFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = if (isAnyOn) JarvisMatteBlack else TextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 3 Individual Lights on this wall (Sub-controllers)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (lightIndex in 0..2) {
                    val isLightOn = group.lights.getOrElse(lightIndex) { false }
                    IndividualLightPill(
                        lightNumber = lightIndex + 1,
                        isOn = isLightOn,
                        onToggle = { onToggleIndividualLight(lightIndex, !isLightOn) },
                        modifier = Modifier.weight(1f),
                        groupId = group.id
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Brightness Dimmer Slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DIM:",
                    fontFamily = OrbitronFontFamily,
                    fontSize = 10.sp,
                    color = TextMuted
                )
                Spacer(modifier = Modifier.width(8.dp))
                Slider(
                    value = group.brightness,
                    onValueChange = onBrightnessChange,
                    valueRange = 10f..100f,
                    steps = 8,
                    colors = SliderDefaults.colors(
                        thumbColor = if (isAnyOn) JarvisRedBright else TextMuted,
                        activeTrackColor = if (isAnyOn) JarvisRedNeon else JarvisBorderSubtle,
                        inactiveTrackColor = JarvisMatteBlack
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .height(28.dp)
                        .testTag("brightness_slider_${group.id}")
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "${group.brightness.toInt()}%",
                    fontFamily = RajdhaniFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = if (isAnyOn) JarvisRedBright else TextMuted,
                    modifier = Modifier.width(36.dp)
                )
            }
        }
    }
}

@Composable
private fun IndividualLightPill(
    lightNumber: Int,
    isOn: Boolean,
    onToggle: () -> Unit,
    groupId: Int,
    modifier: Modifier = Modifier
) {
    val pillBorderColor by animateColorAsState(
        targetValue = if (isOn) JarvisRedNeon else JarvisBorderSubtle,
        label = "pill_border"
    )

    val pillBackground = if (isOn) {
        Brush.verticalGradient(
            colors = listOf(
                JarvisRedDark.copy(alpha = 0.5f),
                JarvisCarbon
            )
        )
    } else {
        Brush.verticalGradient(
            colors = listOf(
                JarvisMatteBlack,
                JarvisCarbon
            )
        )
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(pillBackground)
            .border(1.dp, pillBorderColor, RoundedCornerShape(6.dp))
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onToggle
            )
            .padding(vertical = 8.dp, horizontal = 6.dp)
            .testTag("light_pill_${groupId}_$lightNumber"),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            // Glowing LED Bulb Indicator
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(if (isOn) JarvisRedBright else Color(0xFF333745))
                    .border(
                        0.5.dp,
                        if (isOn) Color.White.copy(alpha = 0.8f) else Color.Transparent,
                        CircleShape
                    )
            )

            Spacer(modifier = Modifier.width(6.dp))

            Text(
                text = "LIGHT $lightNumber",
                fontFamily = RajdhaniFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = if (isOn) TextPrimary else TextMuted
            )
        }
    }
}
