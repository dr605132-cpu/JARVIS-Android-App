package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ConnectionState
import com.example.data.model.Esp32Config
import com.example.data.model.Esp32Status
import com.example.data.model.LightGroup
import com.example.data.repository.Esp32Repository
import com.example.data.repository.PreferencesManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class Screen {
    HOME,
    SETTINGS
}

class JarvisViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = PreferencesManager(application)
    private val repository = Esp32Repository()

    private val _currentScreen = MutableStateFlow(Screen.HOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _config = MutableStateFlow(prefs.loadConfig())
    val config: StateFlow<Esp32Config> = _config.asStateFlow()

    private val _status = MutableStateFlow(
        Esp32Status(
            state = if (_config.value.isDemoMode) ConnectionState.DEMO_MODE else ConnectionState.CONNECTING,
            message = if (_config.value.isDemoMode) "Demo Simulation Active (Ready for ESP32 hardware)" else "Connecting..."
        )
    )
    val status: StateFlow<Esp32Status> = _status.asStateFlow()

    private val _groups = MutableStateFlow<List<LightGroup>>(emptyList())
    val groups: StateFlow<List<LightGroup>> = _groups.asStateFlow()

    private val _voiceDialogOpen = MutableStateFlow(false)
    val voiceDialogOpen: StateFlow<Boolean> = _voiceDialogOpen.asStateFlow()

    private val _isVoiceListening = MutableStateFlow(false)
    val isVoiceListening: StateFlow<Boolean> = _isVoiceListening.asStateFlow()

    private val _lastVoiceCommand = MutableStateFlow("")
    val lastVoiceCommand: StateFlow<String> = _lastVoiceCommand.asStateFlow()

    private val _jarvisResponse = MutableStateFlow("Standing by for your directive, Sir.")
    val jarvisResponse: StateFlow<String> = _jarvisResponse.asStateFlow()

    private val _selectedZoneFilter = MutableStateFlow("ALL") // "ALL", "ZONE_A", "ZONE_B", "ACTIVE"
    val selectedZoneFilter: StateFlow<String> = _selectedZoneFilter.asStateFlow()

    init {
        initWallGroups()
        refreshPing()
    }

    private fun initWallGroups() {
        val deviceNames = listOf("Room Lights", "Projector + TV + Speakers", "AC", "Ambient Lights")
        _groups.value = (1..4).map { id ->
            val name = deviceNames[id - 1]
            LightGroup(id = id, wallName = name, zone = "Home", lights = listOf(false, false, false), brightness = 100f)
        }
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun setZoneFilter(filter: String) {
        _selectedZoneFilter.value = filter
        triggerHaptic()
    }

    fun openVoiceDialog() {
        _voiceDialogOpen.value = true
        _isVoiceListening.value = false
        triggerHaptic()
    }

    fun closeVoiceDialog() {
        _voiceDialogOpen.value = false
        _isVoiceListening.value = false
    }

    fun startListeningSimulation() {
        _isVoiceListening.value = true
        triggerHaptic()
        viewModelScope.launch {
            kotlinx.coroutines.delay(1200)
            _isVoiceListening.value = false
        }
    }

    fun toggleGroup(groupId: Int, turnOn: Boolean) {
        triggerHaptic()
        _groups.update { list ->
            list.map { group ->
                if (group.id == groupId) {
                    group.copy(lights = listOf(turnOn, turnOn, turnOn))
                } else group
            }
        }

        viewModelScope.launch {
            val updated = _groups.value.firstOrNull { it.id == groupId } ?: return@launch
            repository.updateGroupState(_config.value, groupId, updated.lights, updated.brightness)
        }
    }

    fun toggleIndividualLight(groupId: Int, lightIndex: Int, turnOn: Boolean) {
        triggerHaptic()
        _groups.update { list ->
            list.map { group ->
                if (group.id == groupId) {
                    val newLights = group.lights.toMutableList()
                    if (lightIndex in 0..2) {
                        newLights[lightIndex] = turnOn
                    }
                    group.copy(lights = newLights)
                } else group
            }
        }

        viewModelScope.launch {
            val updated = _groups.value.firstOrNull { it.id == groupId } ?: return@launch
            repository.updateGroupState(_config.value, groupId, updated.lights, updated.brightness)
        }
    }

    fun setGroupBrightness(groupId: Int, brightness: Float) {
        _groups.update { list ->
            list.map { group ->
                if (group.id == groupId) {
                    group.copy(brightness = brightness)
                } else group
            }
        }

        viewModelScope.launch {
            val updated = _groups.value.firstOrNull { it.id == groupId } ?: return@launch
            repository.updateGroupState(_config.value, groupId, updated.lights, updated.brightness)
        }
    }

    fun turnAllLights(allOn: Boolean) {
        triggerHaptic(isHeavy = true)
        _groups.update { list ->
            list.map { group ->
                if (group.id == 1) group.copy(lights = listOf(allOn, allOn, allOn)) else group
            }
        }

        viewModelScope.launch {
            repository.updateAllGroups(_config.value, allOn)
            _status.update {
                it.copy(
                    message = if (_config.value.isDemoMode) {
                        "Room lights ${if (allOn) "ON" else "OFF"} (Demo)"
                    } else {
                        "Room lights set to ${if (allOn) "ON" else "OFF"}"
                    }
                )
            }
        }
    }

    fun executeVoiceDirective(rawCommand: String) {
        val cmd = rawCommand.trim().lowercase()
        _lastVoiceCommand.value = rawCommand
        triggerHaptic()

        when {
            cmd.contains("all on") || cmd.contains("turn on all") || cmd.contains("illuminate all") || cmd.contains("room lights on") -> {
                turnAllLights(true)
                _jarvisResponse.value = "Right away, Sir. Room lights are ON."
            }
            cmd.contains("all off") || cmd.contains("turn off all") || cmd.contains("blackout") || cmd.contains("cut all") || cmd.contains("room lights off") -> {
                turnAllLights(false)
                _jarvisResponse.value = "Room lights are OFF, Sir."
            }
            cmd.contains("stealth") || cmd.contains("dim") -> {
                _groups.update { list ->
                    list.map { it.copy(brightness = 20f) }
                }
                _jarvisResponse.value = "Stealth Protocol active. All light intensities restricted to 20%."
            }
            cmd.contains("projector") || cmd.contains("home theatre") || cmd.contains("home theater") || cmd.contains("tv") || cmd.contains("speaker") -> {
                val turnOn = !(cmd.contains("off") || cmd.contains(" बंद"))
                toggleGroup(2, turnOn)
                _jarvisResponse.value = "Home theatre ${if (turnOn) "ON" else "OFF"}, Sir."
            }
            cmd.contains("ambient") -> {
                val turnOn = !cmd.contains("off")
                toggleGroup(4, turnOn)
                _jarvisResponse.value = "Ambient lights ${if (turnOn) "ON" else "OFF"}, Sir."
            }
            cmd.contains("ac") || cmd.contains("air conditioner") -> {
                _jarvisResponse.value = "AC control requires your exact AC brand and model to configure the correct infrared commands, Sir."
            }
            cmd.contains("wall") -> {
                val match = Regex("""wall\s*(\d+)""").find(cmd)
                val wallNum = match?.groupValues?.get(1)?.toIntOrNull()
                if (wallNum != null && wallNum in 1..4) {
                    val turnOn = !cmd.contains("off") && !cmd.contains("cut")
                    toggleGroup(wallNum, turnOn)
                    val wallName = _groups.value.firstOrNull { it.id == wallNum }?.wallName ?: "Wall $wallNum"
                    _jarvisResponse.value = "Acknowledged, Sir. $wallName lights ${if (turnOn) "engaged" else "cut"}."
                } else {
                    _jarvisResponse.value = "I heard the wall command, but could not determine which zone, Sir."
                }
            }
            cmd.contains("diagnostic") || cmd.contains("status") -> {
                refreshPing()
                val activeCount = _groups.value.sumOf { it.activeCount }
                _jarvisResponse.value = "Diagnostics complete, Sir. ESP32 signal ${_status.value.pingMs}ms. $activeCount device channels active."
            }
            else -> {
                _jarvisResponse.value = "Directive noted: \"$rawCommand\". Ready for further instructions, Sir."
            }
        }
    }

    fun refreshPing() {
        viewModelScope.launch {
            val result = repository.ping(_config.value)
            _status.value = result
        }
    }

    fun updateConfig(newConfig: Esp32Config) {
        _config.value = newConfig
        prefs.saveConfig(newConfig)
        refreshPing()
        triggerHaptic()
    }

    fun updateWallName(groupId: Int, newName: String) {
        prefs.saveWallName(groupId, newName)
        _groups.update { list ->
            list.map { group ->
                if (group.id == groupId) group.copy(wallName = newName) else group
            }
        }
    }

    private fun triggerHaptic(isHeavy: Boolean = false) {
        if (!_config.value.hapticEnabled) return
        try {
            val context = getApplication<Application>()
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                manager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            if (vibrator?.hasVibrator() == true) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val effect = if (isHeavy) {
                        VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE)
                    } else {
                        VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE)
                    }
                    vibrator.vibrate(effect)
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(if (isHeavy) 45L else 18L)
                }
            }
        } catch (_: Exception) {
            // Ignore haptic failure gracefully
        }
    }
}
