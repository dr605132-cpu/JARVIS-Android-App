package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ArcReactorCyan
import com.example.ui.theme.JarvisBorderSubtle
import com.example.ui.theme.JarvisCarbon
import com.example.ui.theme.JarvisMatteBlack
import com.example.ui.theme.JarvisRedBright
import com.example.ui.theme.JarvisRedNeon
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Esp32CodeDialog(
    onDismiss: () -> Unit
) {
    val clipboardManager = LocalClipboardManager.current

    val sampleArduinoCode = """
// ==========================================
// JARVIS SMART HOME - ESP32 FIRMWARE
// 12 Wall Groups x 3 Lights = 36 Total Outputs
// ==========================================
#include <WiFi.h>
#include <WebServer.h>

const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASS";

WebServer server(80);

// Example: 12 Groups state (3 lights each)
bool wallLights[12][3] = {false};

void handleStatus() {
  server.send(200, "application/json", "{\"status\":\"ONLINE\",\"system\":\"JARVIS_ESP32\"}");
}

void handleAll() {
  if (server.hasArg("state")) {
    bool state = (server.arg("state") == "1");
    for(int i=0; i<12; i++) {
      for(int j=0; j<3; j++) wallLights[i][j] = state;
    }
  }
  server.send(200, "text/plain", "OK");
}

void handleGroup() {
  if (server.hasArg("id") && server.hasArg("lights")) {
    int id = server.arg("id").toInt() - 1;
    String lightsStr = server.arg("lights");
    // Format: 1,0,1
    if (id >= 0 && id < 12) {
      wallLights[id][0] = (lightsStr.charAt(0) == '1');
      wallLights[id][1] = (lightsStr.charAt(2) == '1');
      wallLights[id][2] = (lightsStr.charAt(4) == '1');
    }
  }
  server.send(200, "text/plain", "OK");
}

void setup() {
  Serial.begin(115200);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
  Serial.println("\nIP Address: " + WiFi.localIP().toString());

  server.on("/status", handleStatus);
  server.on("/api/all", handleAll);
  server.on("/api/group", handleGroup);
  server.begin();
}

void loop() {
  server.handleClient();
}
""".trimIndent()

    BasicAlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("esp32_code_dialog")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(12.dp))
                .background(JarvisCarbon)
                .border(1.5.dp, JarvisBorderSubtle, CutCornerShape(12.dp))
                .padding(18.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "ESP32 FIRMWARE SKETCH",
                            fontFamily = OrbitronFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = ArcReactorCyan
                        )
                        Text(
                            text = "Flash this C++ sketch to your ESP32 microcontroller",
                            fontFamily = RajdhaniFontFamily,
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = TextMuted
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 280.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(JarvisMatteBlack)
                        .border(1.dp, JarvisBorderSubtle, RoundedCornerShape(6.dp))
                        .padding(10.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = sampleArduinoCode,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = Color(0xFF80D8FF),
                        lineHeight = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        clipboardManager.setText(AnnotatedString(sampleArduinoCode))
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = JarvisRedNeon),
                    shape = CutCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("copy_code_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = "Copy code",
                        tint = JarvisMatteBlack,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "COPY ARDUINO CODE",
                        fontFamily = OrbitronFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = JarvisMatteBlack
                    )
                }
            }
        }
    }
}
