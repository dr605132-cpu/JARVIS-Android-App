package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConnectionState
import com.example.data.model.Esp32Config
import com.example.data.model.Esp32Status
import com.example.ui.theme.ArcReactorCyan
import com.example.ui.theme.JarvisBorderSubtle
import com.example.ui.theme.JarvisCarbon
import com.example.ui.theme.JarvisRedBright
import com.example.ui.theme.JarvisRedDark
import com.example.ui.theme.JarvisRedNeon
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HudTelemetryBar(
    status: Esp32Status,
    config: Esp32Config,
    onRefreshPing: () -> Unit,
    onOpenSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val statusColor by animateColorAsState(
        targetValue = when (status.state) {
            ConnectionState.DEMO_MODE -> ArcReactorCyan
            ConnectionState.CONNECTED -> StatusSuccess
            ConnectionState.CONNECTING -> StatusWarning
            ConnectionState.OFFLINE, ConnectionState.ERROR -> StatusError
        },
        label = "status_color"
    )

    val statusLabel = when (status.state) {
        ConnectionState.DEMO_MODE -> "DEMO MODE (ESP32 SIM)"
        ConnectionState.CONNECTED -> "ESP32 ONLINE"
        ConnectionState.CONNECTING -> "SYNCING ESP32..."
        ConnectionState.OFFLINE -> "ESP32 OFFLINE"
        ConnectionState.ERROR -> "ESP32 ERROR"
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(CutCornerShape(bottomEnd = 12.dp, bottomStart = 12.dp))
            .background(JarvisCarbon)
            .border(1.dp, JarvisBorderSubtle, CutCornerShape(bottomEnd = 12.dp, bottomStart = 12.dp))
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag("hud_telemetry_bar")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left: Status & IP Readout
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Pulsing Status Dot
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(statusColor)
                )

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = statusLabel,
                            fontFamily = OrbitronFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = statusColor,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${status.pingMs}ms",
                            fontFamily = RajdhaniFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "${config.baseUrl} • ${if (config.isDemoMode) "Local Simulation" else "HTTP Ready"}",
                        fontFamily = RajdhaniFontFamily,
                        fontSize = 11.sp,
                        color = TextMuted,
                        maxLines = 1
                    )
                }
            }

            // Right: Actions (Ping & Settings)
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onRefreshPing,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("refresh_ping_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Test connection ping",
                        tint = JarvisRedBright,
                        modifier = Modifier.size(20.dp)
                    )
                }

                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Settings,
                        contentDescription = "Configure ESP32",
                        tint = TextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
