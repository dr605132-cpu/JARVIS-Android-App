package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConnectionState
import com.example.data.model.Esp32Config
import com.example.data.model.Esp32Status
import com.example.data.model.LightGroup
import com.example.ui.components.Esp32CodeDialog
import com.example.ui.theme.ArcReactorCyan
import com.example.ui.theme.JarvisBorderSubtle
import com.example.ui.theme.JarvisCarbon
import com.example.ui.theme.JarvisMatteBlack
import com.example.ui.theme.JarvisRedBright
import com.example.ui.theme.JarvisRedDark
import com.example.ui.theme.JarvisRedNeon
import com.example.ui.theme.JarvisSurface
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsScreen(
    config: Esp32Config,
    status: Esp32Status,
    groups: List<LightGroup>,
    onSaveConfig: (Esp32Config) -> Unit,
    onTestPing: () -> Unit,
    onUpdateWallName: (Int, String) -> Unit,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onNavigateBack)

    var ipInput by remember(config.ipAddress) { mutableStateOf(config.ipAddress) }
    var portInput by remember(config.port) { mutableStateOf(config.port.toString()) }
    var isDemoMode by remember(config.isDemoMode) { mutableStateOf(config.isDemoMode) }
    var hapticEnabled by remember(config.hapticEnabled) { mutableStateOf(config.hapticEnabled) }
    var showCodeDialog by remember { mutableStateOf(false) }

    var editingWallId by remember { mutableStateOf<Int?>(null) }
    var editingWallName by remember { mutableStateOf("") }

    if (showCodeDialog) {
        Esp32CodeDialog(onDismiss = { showCodeDialog = false })
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(JarvisMatteBlack),
        containerColor = JarvisMatteBlack,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .background(JarvisCarbon)
                    .border(1.dp, JarvisBorderSubtle)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onNavigateBack,
                    modifier = Modifier.testTag("settings_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Home",
                        tint = JarvisRedBright
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Text(
                        text = "JARVIS SYSTEM SETTINGS",
                        fontFamily = OrbitronFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimary,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "ESP32 Hardware & Network Diagnostics",
                        fontFamily = RajdhaniFontFamily,
                        fontSize = 12.sp,
                        color = TextMuted
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("settings_content_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // ESP32 Connection Card
            item(key = "esp32_connection_card") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(CutCornerShape(12.dp))
                        .background(JarvisCarbon)
                        .border(1.dp, JarvisBorderSubtle, CutCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Router,
                                contentDescription = null,
                                tint = ArcReactorCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ESP32 CONTROLLER WI-FI",
                                fontFamily = OrbitronFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = ArcReactorCyan
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Demo Mode Toggle (Highlighted)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(JarvisMatteBlack)
                                .border(1.dp, if (isDemoMode) ArcReactorCyan.copy(alpha = 0.5f) else JarvisBorderSubtle, RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "DEMO SIMULATION MODE",
                                    fontFamily = OrbitronFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (isDemoMode) ArcReactorCyan else TextPrimary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (isDemoMode)
                                        "ACTIVE: Simulated responses for all 12 walls. Disable when physical ESP32 is powered on."
                                    else
                                        "DISABLED: Real HTTP network calls will be sent to the IP address below.",
                                    fontFamily = RajdhaniFontFamily,
                                    fontSize = 12.sp,
                                    color = TextMuted
                                )
                            }

                            Switch(
                                checked = isDemoMode,
                                onCheckedChange = {
                                    isDemoMode = it
                                    onSaveConfig(
                                        config.copy(
                                            ipAddress = ipInput,
                                            port = portInput.toIntOrNull() ?: 80,
                                            isDemoMode = it,
                                            hapticEnabled = hapticEnabled
                                        )
                                    )
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = ArcReactorCyan,
                                    checkedTrackColor = JarvisCarbon,
                                    uncheckedThumbColor = TextMuted,
                                    uncheckedTrackColor = JarvisMatteBlack
                                ),
                                modifier = Modifier.testTag("demo_mode_switch")
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // IP Address & Port Fields
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = ipInput,
                                onValueChange = { ipInput = it },
                                label = { Text("ESP32 IP Address", fontFamily = RajdhaniFontFamily) },
                                placeholder = { Text("192.168.1.100") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = JarvisRedBright,
                                    unfocusedBorderColor = JarvisBorderSubtle,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary,
                                    focusedContainerColor = JarvisMatteBlack,
                                    unfocusedContainerColor = JarvisMatteBlack
                                ),
                                modifier = Modifier
                                    .weight(2.5f)
                                    .testTag("esp32_ip_input")
                            )

                            OutlinedTextField(
                                value = portInput,
                                onValueChange = { portInput = it },
                                label = { Text("Port", fontFamily = RajdhaniFontFamily) },
                                placeholder = { Text("80") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = JarvisRedBright,
                                    unfocusedBorderColor = JarvisBorderSubtle,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary,
                                    focusedContainerColor = JarvisMatteBlack,
                                    unfocusedContainerColor = JarvisMatteBlack
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("esp32_port_input")
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Save & Ping Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    val port = portInput.toIntOrNull() ?: 80
                                    onSaveConfig(
                                        config.copy(
                                            ipAddress = ipInput,
                                            port = port,
                                            isDemoMode = isDemoMode,
                                            hapticEnabled = hapticEnabled
                                        )
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = JarvisRedNeon),
                                shape = CutCornerShape(6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("save_config_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Save,
                                    contentDescription = null,
                                    tint = JarvisMatteBlack,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "SAVE CONFIG",
                                    fontFamily = OrbitronFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = JarvisMatteBlack
                                )
                            }

                            Button(
                                onClick = onTestPing,
                                colors = ButtonDefaults.buttonColors(containerColor = JarvisSurface),
                                shape = CutCornerShape(6.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .border(1.dp, JarvisBorderSubtle, CutCornerShape(6.dp))
                                    .testTag("test_ping_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.NetworkCheck,
                                    contentDescription = null,
                                    tint = ArcReactorCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "TEST PING",
                                    fontFamily = OrbitronFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = ArcReactorCyan
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Diagnostics Banner
                        Text(
                            text = "STATUS: ${status.message} (${status.pingMs}ms)",
                            fontFamily = RajdhaniFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            color = if (status.state == ConnectionState.ERROR) JarvisRedBright else TextSecondary
                        )
                    }
                }
            }

            // ESP32 Integration & Arduino Code Helper
            item(key = "esp32_firmware_card") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(CutCornerShape(12.dp))
                        .background(JarvisCarbon)
                        .border(1.dp, JarvisBorderSubtle, CutCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Code,
                                contentDescription = null,
                                tint = JarvisRedBright,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "HARDWARE INTEGRATION",
                                fontFamily = OrbitronFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = JarvisRedBright
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Ready to connect physical LEDs or relays? This app exposes clean REST endpoints. Copy the pre-built Arduino sketch directly to your ESP32.",
                            fontFamily = RajdhaniFontFamily,
                            fontSize = 13.sp,
                            color = TextSecondary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { showCodeDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = JarvisMatteBlack),
                            shape = CutCornerShape(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, ArcReactorCyan.copy(alpha = 0.6f), CutCornerShape(6.dp))
                                .testTag("view_firmware_button")
                        ) {
                            Text(
                                text = "VIEW ESP32 ARDUINO FIRMWARE (C++)",
                                fontFamily = OrbitronFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = ArcReactorCyan
                            )
                        }
                    }
                }
            }

            // Haptic & Feedback
            item(key = "haptic_settings_card") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(CutCornerShape(12.dp))
                        .background(JarvisCarbon)
                        .border(1.dp, JarvisBorderSubtle, CutCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Vibration,
                                contentDescription = null,
                                tint = JarvisRedBright,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "TACTILE HAPTIC FEEDBACK",
                                    fontFamily = OrbitronFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "Subtle vibration when triggering Stark HUD controls",
                                    fontFamily = RajdhaniFontFamily,
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }
                        }

                        Switch(
                            checked = hapticEnabled,
                            onCheckedChange = {
                                hapticEnabled = it
                                onSaveConfig(config.copy(hapticEnabled = it))
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = JarvisRedBright,
                                checkedTrackColor = JarvisCarbon
                            ),
                            modifier = Modifier.testTag("haptic_switch")
                        )
                    }
                }
            }

            // Wall Group Name Customization
            item(key = "wall_names_header") {
                Text(
                    text = "RENAME WALL GROUPS (12 WALLS)",
                    fontFamily = OrbitronFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = TextSecondary,
                    letterSpacing = 1.sp
                )
            }

            items(groups, key = { "wall_edit_${it.id}" }) { group ->
                val isEditing = editingWallId == group.id

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(JarvisCarbon)
                        .border(1.dp, JarvisBorderSubtle, RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    if (isEditing) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = editingWallName,
                                onValueChange = { editingWallName = it },
                                label = { Text("Wall ${group.id} Name") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (editingWallName.isNotBlank()) {
                                        onUpdateWallName(group.id, editingWallName)
                                    }
                                    editingWallId = null
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = JarvisRedNeon),
                                shape = CutCornerShape(4.dp)
                            ) {
                                Text("SAVE", fontFamily = OrbitronFontFamily, color = JarvisMatteBlack)
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = String.format("WALL %02d", group.id),
                                    fontFamily = OrbitronFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = ArcReactorCyan
                                )
                                Text(
                                    text = group.wallName,
                                    fontFamily = RajdhaniFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = TextPrimary
                                )
                            }

                            IconButton(
                                onClick = {
                                    editingWallId = group.id
                                    editingWallName = group.wallName
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Rename Wall ${group.id}",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }

            item(key = "settings_footer") {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
