package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val JarvisColorScheme = darkColorScheme(
    primary = JarvisRedNeon,
    onPrimary = JarvisMatteBlack,
    primaryContainer = JarvisRedDark,
    onPrimaryContainer = JarvisRedBright,
    secondary = ArcReactorCyan,
    onSecondary = JarvisMatteBlack,
    secondaryContainer = ArcReactorCyanDim,
    onSecondaryContainer = ArcReactorCyan,
    tertiary = StarkAmber,
    onTertiary = JarvisMatteBlack,
    background = JarvisMatteBlack,
    onBackground = TextPrimary,
    surface = JarvisSurface,
    onSurface = TextPrimary,
    surfaceVariant = JarvisSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = JarvisRedBorder,
    outlineVariant = JarvisBorderSubtle
)

@Composable
fun JarvisTheme(
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = JarvisMatteBlack.toArgb()
                window.navigationBarColor = JarvisMatteBlack.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = JarvisColorScheme,
        typography = Typography,
        content = content
    )
}
