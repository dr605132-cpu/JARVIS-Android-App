package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ArcReactorCyan
import com.example.ui.theme.JarvisMatteBlack
import com.example.ui.theme.JarvisRedBright
import com.example.ui.theme.JarvisRedDark
import com.example.ui.theme.JarvisRedGlow
import com.example.ui.theme.JarvisRedNeon
import com.example.ui.theme.OrbitronFontFamily
import com.example.ui.theme.RajdhaniFontFamily
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun JarvisArcIndicator(
    modifier: Modifier = Modifier,
    size: Dp = 160.dp,
    isActive: Boolean = true,
    activeLightsCount: Int = 0,
    totalLightsCount: Int = 36,
    statusText: String = "JARVIS ONLINE",
    subText: String = "ALL SYSTEMS NOMINAL",
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "jarvis_arc_loop")

    // Slow clockwise rotation for outer dial
    val outerAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(22000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outer_angle"
    )

    // Counter-clockwise rotation for inner technical ring
    val innerAngle by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "inner_angle"
    )

    // Pulsing glowing energy core
    val pulseRatio by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_ratio"
    )

    Box(
        modifier = modifier
            .size(size)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onClick
            )
            .testTag("jarvis_indicator_core"),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val baseRadius = this.size.minDimension / 2f

            // Outer subtle radial halo glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        JarvisRedGlow.copy(alpha = if (isActive) 0.35f else 0.15f),
                        JarvisRedDark.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius
                ),
                radius = baseRadius
            )

            // Outer Segmented Technical Ring (Clockwise)
            rotate(outerAngle, pivot = center) {
                // 12 Outer perimeter ticks
                val tickCount = 24
                for (i in 0 until tickCount) {
                    val angleRad = (i * (360f / tickCount)) * (PI / 180f).toFloat()
                    val isMajor = i % 4 == 0
                    val tickLen = if (isMajor) baseRadius * 0.10f else baseRadius * 0.05f
                    val rOut = baseRadius * 0.96f
                    val rIn = rOut - tickLen

                    val start = Offset(
                        center.x + rIn * cos(angleRad),
                        center.y + rIn * sin(angleRad)
                    )
                    val end = Offset(
                        center.x + rOut * cos(angleRad),
                        center.y + rOut * sin(angleRad)
                    )

                    drawLine(
                        color = if (isMajor) JarvisRedNeon else JarvisRedDark.copy(alpha = 0.7f),
                        start = start,
                        end = end,
                        strokeWidth = if (isMajor) 2.2f else 1.2f,
                        cap = StrokeCap.Round
                    )
                }

                // Segmented dashed outer circle
                drawCircle(
                    color = JarvisRedNeon.copy(alpha = 0.5f),
                    radius = baseRadius * 0.88f,
                    style = Stroke(
                        width = 1.5f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 10f, 6f, 10f), 0f)
                    )
                )
            }

            // Inner Technical Ring (Counter-Clockwise)
            rotate(innerAngle, pivot = center) {
                // Triangular node brackets or 3 arc coils
                val coilCount = 8
                for (i in 0 until coilCount) {
                    val angleRad = (i * (360f / coilCount)) * (PI / 180f).toFloat()
                    val rOut = baseRadius * 0.78f
                    val rIn = baseRadius * 0.65f

                    val start = Offset(
                        center.x + rIn * cos(angleRad),
                        center.y + rIn * sin(angleRad)
                    )
                    val end = Offset(
                        center.x + rOut * cos(angleRad),
                        center.y + rOut * sin(angleRad)
                    )

                    drawLine(
                        color = if (i % 2 == 0) JarvisRedBright else ArcReactorCyan.copy(alpha = 0.8f),
                        start = start,
                        end = end,
                        strokeWidth = 3f,
                        cap = StrokeCap.Square
                    )
                }

                // Inner fine guide circle
                drawCircle(
                    color = ArcReactorCyan.copy(alpha = 0.35f),
                    radius = baseRadius * 0.62f,
                    style = Stroke(
                        width = 1.2f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f), 0f)
                    )
                )
            }

            // Glowing Arc Core with pulsing sine wave
            val coreRadius = baseRadius * 0.48f * pulseRatio
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color(0xFFFF8A80),
                        JarvisRedNeon,
                        JarvisRedDark,
                        Color.Transparent
                    ),
                    center = center,
                    radius = coreRadius
                ),
                radius = coreRadius
            )

            // Inner dark containment pupil
            drawCircle(
                color = JarvisMatteBlack.copy(alpha = 0.82f),
                radius = baseRadius * 0.38f
            )

            // Center neon pin ring
            drawCircle(
                color = JarvisRedBright,
                radius = baseRadius * 0.36f,
                style = Stroke(width = 1.8f)
            )

            // Core center energy dot
            drawCircle(
                color = Color.White,
                radius = 3.dp.toPx() * pulseRatio
            )
        }

        // Center HUD Telemetry Text
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(8.dp)
        ) {
            Text(
                text = "JARVIS",
                fontFamily = OrbitronFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = JarvisRedBright,
                letterSpacing = 2.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "$activeLightsCount / $totalLightsCount",
                fontFamily = RajdhaniFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = TextPrimary
            )
            Text(
                text = "ONLINE",
                fontFamily = RajdhaniFontFamily,
                fontWeight = FontWeight.SemiBold,
                fontSize = 9.sp,
                color = ArcReactorCyan,
                letterSpacing = 1.sp
            )
        }
    }
}
