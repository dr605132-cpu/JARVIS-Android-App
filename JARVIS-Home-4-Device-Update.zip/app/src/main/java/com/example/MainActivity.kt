package com.example

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.JarvisVoiceDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.JarvisTheme
import com.example.ui.viewmodel.JarvisViewModel
import com.example.ui.viewmodel.Screen
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            JarvisTheme {
                JarvisSmartHomeApp()
            }
        }
    }
}

@Composable
fun JarvisSmartHomeApp(
    viewModel: JarvisViewModel = viewModel()
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val groups by viewModel.groups.collectAsStateWithLifecycle()
    val config by viewModel.config.collectAsStateWithLifecycle()
    val status by viewModel.status.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedZoneFilter.collectAsStateWithLifecycle()

    val isVoiceOpen by viewModel.voiceDialogOpen.collectAsStateWithLifecycle()
    val isListening by viewModel.isVoiceListening.collectAsStateWithLifecycle()
    val lastVoiceCommand by viewModel.lastVoiceCommand.collectAsStateWithLifecycle()
    val jarvisResponse by viewModel.jarvisResponse.collectAsStateWithLifecycle()

    // Speech Recognizer Launcher for real speech input
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val spokenMatches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = spokenMatches?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                viewModel.executeVoiceDirective(spokenText)
            }
        }
    }

    Crossfade(
        targetState = currentScreen,
        label = "screen_crossfade",
        modifier = Modifier.fillMaxSize()
    ) { screen ->
        when (screen) {
            Screen.HOME -> {
                HomeScreen(
                    groups = groups,
                    config = config,
                    status = status,
                    selectedFilter = selectedFilter,
                    onFilterSelect = { viewModel.setZoneFilter(it) },
                    onToggleGroup = { groupId, turnOn ->
                        viewModel.toggleGroup(groupId, turnOn)
                    },
                    onToggleIndividualLight = { groupId, lightIndex, turnOn ->
                        viewModel.toggleIndividualLight(groupId, lightIndex, turnOn)
                    },
                    onBrightnessChange = { groupId, brightness ->
                        viewModel.setGroupBrightness(groupId, brightness)
                    },
                    onTurnAllLights = { turnOn ->
                        viewModel.turnAllLights(turnOn)
                    },
                    onOpenVoiceDialog = {
                        viewModel.openVoiceDialog()
                    },
                    onRefreshPing = {
                        viewModel.refreshPing()
                    },
                    onOpenSettings = {
                        viewModel.navigateTo(Screen.SETTINGS)
                    }
                )
            }

            Screen.SETTINGS -> {
                SettingsScreen(
                    config = config,
                    status = status,
                    groups = groups,
                    onSaveConfig = { newConfig ->
                        viewModel.updateConfig(newConfig)
                    },
                    onTestPing = {
                        viewModel.refreshPing()
                    },
                    onUpdateWallName = { groupId, newName ->
                        viewModel.updateWallName(groupId, newName)
                    },
                    onNavigateBack = {
                        viewModel.navigateTo(Screen.HOME)
                    }
                )
            }
        }
    }

    // Voice Directive Dialog Overlay
    if (isVoiceOpen) {
        JarvisVoiceDialog(
            isListening = isListening,
            lastVoiceCommand = lastVoiceCommand,
            jarvisResponse = jarvisResponse,
            onSendCommand = { cmd ->
                viewModel.executeVoiceDirective(cmd)
            },
            onStartListening = {
                // Launch Android Speech Intent or fall back to simulation
                try {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(
                            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                        )
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS is listening for home directive...")
                    }
                    speechLauncher.launch(intent)
                } catch (e: Exception) {
                    // Fall back to animated speech listening simulation
                    viewModel.startListeningSimulation()
                }
            },
            onDismiss = {
                viewModel.closeVoiceDialog()
            }
        )
    }
}
