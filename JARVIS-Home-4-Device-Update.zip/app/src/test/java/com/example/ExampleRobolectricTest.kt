package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.LightGroup
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("JARVIS Home", appName)
  }

  @Test
  fun `light group calculates active lights and power correctly`() {
    val group = LightGroup(
      id = 1,
      wallName = "North Gallery",
      zone = "Zone Alpha",
      lights = listOf(true, false, true),
      brightness = 100f
    )
    assertEquals(2, group.activeCount)
    assertTrue(group.isAnyOn)
    assertEquals(17.0f, group.totalWatts, 0.1f)
  }
}

