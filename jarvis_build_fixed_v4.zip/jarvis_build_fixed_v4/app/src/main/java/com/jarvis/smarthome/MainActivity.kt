package com.jarvis.smarthome

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.*
import java.util.concurrent.TimeUnit

data class RelayDevice(
    val id: Int,
    val name: String,
    val endpointOn: String,
    val endpointOff: String,
    val isOn: Boolean = false
)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Wake & show on lock screen
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        )

        tts = TextToSpeech(this, this)

        setContent {
            JarvisSmartHomeTheme {
                JarvisDashboard(
                    onSpeak = { text -> speakOut(text) },
                    onSendEspCommand = { ip, path -> sendEspRequest(ip, path) }
                )
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("en", "IN")
            speakOut("Systems online. Ready for command, Sir.")
        }
    }

    private fun speakOut(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, null)
    }

    private suspend fun sendEspRequest(ip: String, path: String): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                val cleanIp = ip.trim().removePrefix("http://").removeSuffix("/")
                val url = "http://$cleanIp/$path"
                val request = Request.Builder().url(url).build()
                httpClient.newCall(request).execute().use { response ->
                    response.isSuccessful
                }
            } catch (e: Exception) {
                false
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
fun JarvisSmartHomeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF00E5FF),
            secondary = Color(0xFF00B8D4),
            background = Color(0xFF050B14),
            surface = Color(0xFF0D1624)
        ),
        content = content
    )
}

@Composable
fun JarvisDashboard(
    onSpeak: (String) -> Unit,
    onSendEspCommand: suspend (String, String) -> Boolean
) {
    val scope = rememberCoroutineScope()
    var espIp by remember { mutableStateOf("192.168.1.100") }
    var statusLog by remember { mutableStateOf("J.A.R.V.I.S ONLINE // STANDBY") }

    var devices by remember {
        mutableStateOf(
            listOf(
                RelayDevice(1, "Main Room Light", "relay1/on", "relay1/off"),
                RelayDevice(2, "Ceiling Ambient LED", "relay2/on", "relay2/off"),
                RelayDevice(3, "Sound Amplifier", "relay3/on", "relay3/off"),
                RelayDevice(4, "Smart Socket / Fan", "relay4/on", "relay4/off")
            )
        )
    }

    fun toggleDevice(device: RelayDevice, targetState: Boolean) {
        val path = if (targetState) device.endpointOn else device.endpointOff
        scope.launch {
            statusLog = "TRANSMITTING -> http://$espIp/$path ..."
            val ok = onSendEspCommand(espIp, path)
            devices = devices.map {
                if (it.id == device.id) it.copy(isOn = targetState) else it
            }
            val stateText = if (targetState) "ON" else "OFF"
            if (ok) {
                val msg = "${device.name} turned $stateText, Sir."
                statusLog = "SUCCESS: $msg"
                onSpeak(msg)
            } else {
                statusLog = "ESP OFFLINE: ${device.name} switched $stateText locally"
                onSpeak("${device.name} $stateText")
            }
        }
    }

    val voiceLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = matches?.firstOrNull()?.lowercase(Locale.getDefault()) ?: ""
            if (spokenText.isNotEmpty()) {
                statusLog = "VOICE INPUT: \"$spokenText\""
                val turnOn = spokenText.contains("on") || spokenText.contains("chalu") || spokenText.contains("jala")
                val turnOff = spokenText.contains("off") || spokenText.contains("band")

                when {
                    spokenText.contains("all") || spokenText.contains("saari") || spokenText.contains("sab") -> {
                        val state = !turnOff
                        devices.forEach { toggleDevice(it, state) }
                        onSpeak("Switching all systems ${if (state) "on" else "off"}, Sir.")
                    }
                    spokenText.contains("main") || spokenText.contains("one") || spokenText.contains("1") -> {
                        toggleDevice(devices[0], !turnOff)
                    }
                    spokenText.contains("led") || spokenText.contains("two") || spokenText.contains("2") -> {
                        toggleDevice(devices[1], !turnOff)
                    }
                    spokenText.contains("sound") || spokenText.contains("amp") || spokenText.contains("3") -> {
                        toggleDevice(devices[2], !turnOff)
                    }
                    spokenText.contains("fan") || spokenText.contains("socket") || spokenText.contains("4") -> {
                        toggleDevice(devices[3], !turnOff)
                    }
                    else -> {
                        onSpeak("Command received: $spokenText")
                    }
                }
            }
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF040911), Color(0xFF0A192F), Color(0xFF040911))
                )
            )
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "J.A.R.V.I.S.",
                    color = Color(0xFF00E5FF),
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "SMART HOME MATRIX // ACTIVE",
                    color = Color(0xFF64FFDA),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Icon(
                imageVector = Icons.Default.Memory,
                contentDescription = "Core",
                tint = Color(0xFF00E5FF),
                modifier = Modifier.size(32.dp)
            )
        }

        OutlinedTextField(
            value = espIp,
            onValueChange = { espIp = it },
            label = { Text("ESP32 Local IP Address", color = Color(0xFF00E5FF)) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Color(0xFF00E5FF),
                unfocusedBorderColor = Color(0xFF1E3A5F),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        )

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(130.dp)
                .scale(pulseScale)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(Color(0xFF00E5FF).copy(alpha = 0.35f), Color(0xFF050B14))
                    )
                )
                .border(3.dp, Color(0xFF00E5FF), CircleShape)
                .clickable {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(
                            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                        )
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak command to JARVIS...")
                    }
                    voiceLauncher.launch(intent)
                }
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Voice Command",
                    tint = Color(0xFF00E5FF),
                    modifier = Modifier.size(42.dp)
                )
                Text(
                    text = "TAP TO SPEAK",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF08121E))
                .border(1.dp, Color(0xFF00E5FF).copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Text(
                text = statusLog,
                color = Color(0xFF64FFDA),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(devices) { device ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(
                        1.5.dp,
                        if (device.isOn) Color(0xFF00E5FF) else Color(0xFF1E2D3D)
                    ),
                    colors = CardDefaults.cardColors(
                        containerColor = if (device.isOn) Color(0xFF0B253A) else Color(0xFF0D1624)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { toggleDevice(device, !device.isOn) }
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (device.isOn) Icons.Default.Bolt else Icons.Default.PowerSettingsNew,
                                contentDescription = device.name,
                                tint = if (device.isOn) Color(0xFF00E5FF) else Color.Gray
                            )
                            Text(
                                text = if (device.isOn) "ONLINE" else "STANDBY",
                                color = if (device.isOn) Color(0xFF00E5FF) else Color.Gray,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = device.name,
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "CH-0${device.id} // ESP32",
                            color = Color(0xFF8892B0),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { devices.forEach { toggleDevice(it, true) } },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00B8D4)),
                modifier = Modifier.weight(1f)
            ) {
                Text("ALL LIGHTS ON", color = Color.Black, fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
                onClick = { devices.forEach { toggleDevice(it, false) } },
                border = BorderStroke(1.dp, Color(0xFFFF5252)),
                modifier = Modifier.weight(1f)
            ) {
                Text("ALL OFF", color = Color(0xFFFF5252), fontWeight = FontWeight.Bold)
            }
        }
    }
}
